import logo from './logo.svg';
import './App.css';
import Header from './Componants/Header';
import SelectForm from './Componants/SelectForm';
import { BrowserRouter } from 'react-router-dom';
import { HashLink as Link } from "react-router-hash-link";
import Navbar from './Componants/Navbar';
import Login from './Componants/Login';
import { Router } from 'react-router-dom';
import { Route,Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      
      {/* <Navbar /> */}
      {/* <Login/>
      <SelectForm /> */}
      <BrowserRouter>
        <Routes>
        <Route path='/' element={<Login/>}/>
        <Route path='/uploadpdf' element={<Header/>}/>
        </Routes>
      </BrowserRouter>
      {/* <Header /> */}
    </div>

  );
}

export default App;