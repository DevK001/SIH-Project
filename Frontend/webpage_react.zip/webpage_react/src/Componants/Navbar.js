import React, { useState } from 'react'
import SelectForm from './SelectForm';

function Navbar() {
  return (
    <div>
      <div className="logo"><img src="./AICTE_LOGO.png" alt="logo" />
      </div>
      <div>
        <hr className='h'></hr>
      </div>
      <SelectForm/>
    </div>
    
  );
}

export default Navbar
