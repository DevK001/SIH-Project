import React from "react";
import { Navbar } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import "./Login.css";

function Login() {
  return (
    <div>
      <div>
        <div className="logo">
          <img src="./AICTE_LOGO.png" alt="logo" />
        </div>
        <div>
          <hr className="h"></hr>
        </div>
      </div>
      <h1>Institute/collage and Unervisity</h1>
      <Card className="box1">
        <h3>Authorized Login</h3>
        <Form>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            {/* <div className="field"> */}
              <div className="email">
                <Form.Label>Email </Form.Label>
              </div>
              <Form.Control type="email" placeholder="Enter email" />
            {/* </div> */}
          </Form.Group>
          <br></br>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <div className="email">
              <Form.Label>Password</Form.Label>
            </div>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>
          <br></br>
          {/* <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group> */}
          <br></br>
          <button1 type="button">
            <a href="/uploadpdf" className="link_remove">
              Login
            </a>
          </button1>
        </Form>
      </Card>
    </div>
  );
}

export default Login;
