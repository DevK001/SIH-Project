import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import axios from "axios";

function Header() {
  const [state, setState] = useState({ file: null });
  // SelectForm
  const Istates = [
    { id: "1", name: "Gujrat" },
    { id: "2", name: "Tamilnadu" },
    { id: "3", name: "Kerala" },
    { id: "4", name: "Maharashtra" },
    { id: "5", name: "Uttar Pradesh" }
];

const IinstituteTypes = [
    { id: "1", stateId: "1", name: "Graint in aid" },
    { id: "2", stateId: "1", name: "Semi-goverment" },
    { id: "3", stateId: "1", name: "Self-financed" },

    { id: "4", stateId: "2", name: "Graint in aid" },
    { id: "5", stateId: "2", name: "Semi-goverment" },
    { id: "6", stateId: "2", name: "Self-financed" },

    { id: "7", stateId: "3", name: "Graint in aid" },
    { id: "8", stateId: "3", name: "Semi-goverment" },
    { id: "9", stateId: "3", name: "Self-financed" },

    { id: "10", stateId: "4", name: "Graint in aid" },
    { id: "11", stateId: "4", name: "Semi-goverment" },
    { id: "12", stateId: "4", name: "Self-financed" },

    { id: "13", stateId: "5", name: "Graint in aid" },
    { id: "14", stateId: "5", name: "Semi-goverment" },
    { id: "15", stateId: "5", name: "Self-financed" },
]

const Iinstitutes = [
    { id: "1", institutetypeId: "3", name: "Charusat University" },
    { id: "2", institutetypeId: "1", name: "BVM" },
    { id: "3", institutetypeId: "3", name: "Parul University" },
    { id: "4", institutetypeId: "3", name: "Nirma University" },
    { id: "5", institutetypeId: "3", name: "Dhirubhai Ambani Institute of Information and Communication Technology" },
    { id: "6", institutetypeId: "2", name: "Vishwakarma Government Engineering College" },
    { id: "7", institutetypeId: "6", name: "Anna University"},
    { id: "8", institutetypeId: "6", name: "Vellore Institute of Technology" },
    { id: "9", institutetypeId: "5", name: "Sri Krishna College of Engineering and Technology" },
    { id: "10", institutetypeId: "5", name: " Vel Tech Rangarajan Dr Sagunthala R and D Institute of Science and Technology" },
    { id: "11", institutetypeId: "9", name: " Amal Jyothi College of Engineering" },
    { id: "12", institutetypeId: "9", name: " Cochin Institute of Science and Technology" },
    { id: "13", institutetypeId: "7", name: " Government Engineering College, Thrissur" },
    { id: "14", institutetypeId: "7", name: " Rajiv Gandhi Institute of Technology, Kottayam" },
    { id: "15", institutetypeId: "8", name: " Government Engineering College, Thrissur" },
    { id: "16", institutetypeId: "8", name: " Rajiv Gandhi Institute of Technology, Kottayam" },
    { id: "17", institutetypeId: "10", name: "Laxminarayan Institute of Technology" },
    { id: "18", institutetypeId: "10", name: "Department of Technology, Shivaji University, Kolhapur" },
    { id: "19", institutetypeId: "10", name: "Veermata Jijabai Technological Institute" },
    { id: "20", institutetypeId: "11", name: "Smt kashibai Navale medical college, pune" },
    { id: "21", institutetypeId: "11", name: "Prakash Institute of Medical Science& research, Samgli" },
    { id: "22", institutetypeId: "11", name: "K. J Somaiya Medical college, Sion, Mumbai" },
    { id: "23", institutetypeId: "11", name: "N. K. P salne Institute of medical science, Nagpur" },
    { id: "24", institutetypeId: "12", name: "D. Y. Patil International University" },
    { id: "25", institutetypeId: "12", name: "Shahid Bhagat Singh Jr. College" },
    { id: "26", institutetypeId: "12", name: "Ajeenkya DY Patil University" },
    { id: "27", institutetypeId: "13", name: " Chhatrapati Shahu Ji Maharaj University, Kanpur" },
    { id: "28", institutetypeId: "13", name: "Dr. A.P.J. Abdul Kalam Technical University" },
    { id: "29", institutetypeId: "13", name: "Mahatma Jyotiba Phule Rohilkhand University" },
    { id: "30", institutetypeId: "14", name: "Motilal Nehru National Institute of Technology (MNNIT), Allahabad" },
    { id: "31", institutetypeId: "15", name: "Integral University, Lucknow" },
    { id: "32", institutetypeId: "15", name: "Bennett University, Greater Noida" },


]

const Ifields = [
    { id: "1", instituteId: "1", name: "Enginering" },
    { id: "2", instituteId: "1", name: "Pharmacy" },
    { id: "3", instituteId: "1", name: "Managment" },
    { id: "4", instituteId: "1", name: "Architecture" },

    { id: "1", instituteId: "2", name: "Enginering" },
    { id: "2", instituteId: "2", name: "Pharmacy" },
    { id: "3", instituteId: "2", name: "Managment" },
    { id: "4", instituteId: "2", name: "Architecture" },

    { id: "1", instituteId: "3", name: "Enginering" },
    { id: "2", instituteId: "3", name: "Pharmacy" },
    { id: "3", instituteId: "3", name: "Managment" },
    { id: "4", instituteId: "3", name: "Architecture" },

    { id: "1", instituteId: "4", name: "Enginering" },
    { id: "2", instituteId: "4", name: "Pharmacy" },
    { id: "3", instituteId: "4", name: "Managment" },
    { id: "4", instituteId: "4", name: "Architecture" },

    { id: "1", instituteId: "5", name: "Enginering" },
    { id: "2", instituteId: "5", name: "Pharmacy" },
    { id: "3", instituteId: "5", name: "Managment" },
    { id: "4", instituteId: "5", name: "Architecture" },

    { id: "1", instituteId: "6", name: "Enginering" },
    { id: "2", instituteId: "6", name: "Pharmacy" },
    { id: "3", instituteId: "6", name: "Managment" },
    { id: "4", instituteId: "6", name: "Architecture" },

    { id: "1", instituteId: "7", name: "Enginering" },
    { id: "2", instituteId: "7", name: "Pharmacy" },
    { id: "3", instituteId: "7", name: "Managment" },
    { id: "4", instituteId: "7", name: "Architecture" },

    { id: "1", instituteId: "8", name: "Enginering" },
    { id: "2", instituteId: "8", name: "Pharmacy" },
    { id: "3", instituteId: "8", name: "Managment" },
    { id: "4", instituteId: "8", name: "Architecture" },

    { id: "1", instituteId: "9", name: "Enginering" },
    { id: "2", instituteId: "9", name: "Pharmacy" },
    { id: "3", instituteId: "9", name: "Managment" },
    { id: "4", instituteId: "9", name: "Architecture" },

    { id: "1", instituteId: "10", name: "Enginering" },
    { id: "2", instituteId: "10", name: "Pharmacy" },
    { id: "3", instituteId: "10", name: "Managment" },
    { id: "4", instituteId: "10", name: "Architecture" },

    { id: "1", instituteId: "11", name: "Enginering" },
    { id: "2", instituteId: "11", name: "Pharmacy" },
    { id: "3", instituteId: "11", name: "Managment" },
    { id: "4", instituteId: "11", name: "Architecture" },

    { id: "1", instituteId: "12", name: "Enginering" },
    { id: "2", instituteId: "12", name: "Pharmacy" },
    { id: "3", instituteId: "12", name: "Managment" },
    { id: "4", instituteId: "12", name: "Architecture" },

    { id: "1", instituteId: "13", name: "Enginering" },
    { id: "2", instituteId: "13", name: "Pharmacy" },
    { id: "3", instituteId: "13", name: "Managment" },
    { id: "4", instituteId: "13", name: "Architecture" },

    { id: "1", instituteId: "14", name: "Enginering" },
    { id: "2", instituteId: "14", name: "Pharmacy" },
    { id: "3", instituteId: "14", name: "Managment" },
    { id: "4", instituteId: "14", name: "Architecture" },

    { id: "1", instituteId: "15", name: "Enginering" },
    { id: "2", instituteId: "15", name: "Pharmacy" },
    { id: "3", instituteId: "15", name: "Managment" },
    { id: "4", instituteId: "15", name: "Architecture" },

    { id: "1", instituteId: "16", name: "Enginering" },
    { id: "2", instituteId: "16", name: "Pharmacy" },
    { id: "3", instituteId: "16", name: "Managment" },
    { id: "4", instituteId: "16", name: "Architecture" },

    { id: "1", instituteId: "17", name: "Enginering" },
    { id: "2", instituteId: "17", name: "Pharmacy" },
    { id: "3", instituteId: "17", name: "Managment" },
    { id: "4", instituteId: "17", name: "Architecture" },

    { id: "1", instituteId: "18", name: "Enginering" },
    { id: "2", instituteId: "18", name: "Pharmacy" },
    { id: "3", instituteId: "18", name: "Managment" },
    { id: "4", instituteId: "18", name: "Architecture" },

    { id: "1", instituteId: "19", name: "Enginering" },
    { id: "2", instituteId: "19", name: "Pharmacy" },
    { id: "3", instituteId: "19", name: "Managment" },
    { id: "4", instituteId: "19", name: "Architecture" },

    { id: "1", instituteId: "20", name: "Enginering" },
    { id: "2", instituteId: "20", name: "Pharmacy" },
    { id: "3", instituteId: "20", name: "Managment" },
    { id: "4", instituteId: "20", name: "Architecture" },

    { id: "1", instituteId: "21", name: "Enginering" },
    { id: "2", instituteId: "21", name: "Pharmacy" },
    { id: "3", instituteId: "21", name: "Managment" },
    { id: "4", instituteId: "21", name: "Architecture" },

    { id: "1", instituteId: "22", name: "Enginering" },
    { id: "2", instituteId: "22", name: "Pharmacy" },
    { id: "3", instituteId: "22", name: "Managment" },
    { id: "4", instituteId: "22", name: "Architecture" },

    { id: "1", instituteId: "23", name: "Enginering" },
    { id: "2", instituteId: "23", name: "Pharmacy" },
    { id: "3", instituteId: "23", name: "Managment" },
    { id: "4", instituteId: "23", name: "Architecture" },

    { id: "1", instituteId: "24", name: "Enginering" },
    { id: "2", instituteId: "24", name: "Pharmacy" },
    { id: "3", instituteId: "24", name: "Managment" },
    { id: "4", instituteId: "24", name: "Architecture" },

    { id: "1", instituteId: "25", name: "Enginering" },
    { id: "2", instituteId: "25", name: "Pharmacy" },
    { id: "3", instituteId: "25", name: "Managment" },
    { id: "4", instituteId: "25", name: "Architecture" },

    { id: "1", instituteId: "26", name: "Enginering" },
    { id: "2", instituteId: "26", name: "Pharmacy" },
    { id: "3", instituteId: "26", name: "Managment" },
    { id: "4", instituteId: "26", name: "Architecture" },

    { id: "1", instituteId: "27", name: "Enginering" },
    { id: "2", instituteId: "27", name: "Pharmacy" },
    { id: "3", instituteId: "27", name: "Managment" },
    { id: "4", instituteId: "27", name: "Architecture" },

    { id: "1", instituteId: "28", name: "Enginering" },
    { id: "2", instituteId: "28", name: "Pharmacy" },
    { id: "3", instituteId: "28", name: "Managment" },
    { id: "4", instituteId: "28", name: "Architecture" },

    { id: "1", instituteId: "29", name: "Enginering" },
    { id: "2", instituteId: "29", name: "Pharmacy" },
    { id: "3", instituteId: "29", name: "Managment" },
    { id: "4", instituteId: "29", name: "Architecture" },

    { id: "1", instituteId: "30", name: "Enginering" },
    { id: "2", instituteId: "30", name: "Pharmacy" },
    { id: "3", instituteId: "30", name: "Managment" },
    { id: "4", instituteId: "30", name: "Architecture" },

    { id: "1", instituteId: "31", name: "Enginering" },
    { id: "2", instituteId: "31", name: "Pharmacy" },
    { id: "3", instituteId: "31", name: "Managment" },
    { id: "4", instituteId: "31", name: "Architecture" },

    { id: "1", instituteId: "32", name: "Enginering" },
    { id: "2", instituteId: "32", name: "Pharmacy" },
    { id: "3", instituteId: "32", name: "Managment" },
    { id: "4", instituteId: "32", name: "Architecture" },
]

const Icollages = [
  {id: "1", instituteId: "7", name: "Paavai Engineering College, Namakkal"},
  {id: "2", instituteId: "7", name: "Bannari Amman Institute of Technology, Erode"},
  {id: "3", instituteId: "7", name: "SNS College of Technology, Coimbatore"},

  {id: "4", instituteId: "1", name: "Chandu bhai s. patel Institute of technology"},
  {id: "5", instituteId: "1", name: "Devang Patel Institute of technology"},

]

const Ibranches = [
    { id: "1", fieldId: "1", name: "Information & Technology" },
    { id: "2", fieldId: "1", name: "computer Enginnering" },
    { id: "3", fieldId: "1", name: "computer Science & Enginnering" },

    { id: "4", fieldId: "2", name: "Medicinal Chemistry" },
    { id: "5", fieldId: "2", name: "Pharmaceutics" },
    // { id: "6", fieldId: "2", name: "computer Science & Enginnering" },

    { id: "7", fieldId: "3", name: "Financial Management" },
    { id: "8", fieldId: "3", name: "Marketing Management" },
    { id: "9", fieldId: "3", name: "Strategic management" },

    { id: "10", fieldId: "4", name: "Landscape Architecture" },
    { id: "11", fieldId: "4", name: "Reserch Architecture" },
    { id: "12", fieldId: "4", name: "Political Architechture" },
]


const Isemesters = [
  {id: "1", branchId: "1", name: "1"},
  {id: "2", branchId: "1", name: "2"},
  {id: "3", branchId: "1", name: "3"},
  {id: "4", branchId: "1", name: "4"},
  {id: "5", branchId: "1", name: "5"},
  {id: "6", branchId: "1", name: "6"},
  {id: "7", branchId: "1", name: "7"},
  {id: "8", branchId: "1", name: "8"},

  {id: "9", branchId: "2", name: "1"},
  {id: "10", branchId: "2", name: "2"},
  {id: "11", branchId: "2", name: "3"},
  {id: "12", branchId: "2", name: "4"},
  {id: "13", branchId: "2", name: "5"},
  {id: "14", branchId: "2", name: "6"},
  {id: "15", branchId: "2", name: "7"},
  {id: "16", branchId: "2", name: "8"},

  {id: "16", branchId: "3", name: "1"},
  {id: "17", branchId: "3", name: "2"},
  {id: "18", branchId: "3", name: "3"},
  {id: "19", branchId: "3", name: "4"},
  {id: "20", branchId: "3", name: "5"},
  {id: "21", branchId: "3", name: "6"},
  {id: "22", branchId: "3", name: "7"},
  {id: "23", branchId: "3", name: "8"},

  {id: "24", branchId: "4", name: "1"},
  {id: "25", branchId: "4", name: "2"},
  {id: "26", branchId: "4", name: "3"},
  {id: "27", branchId: "4", name: "4"},
  {id: "28", branchId: "4", name: "5"},
  {id: "29", branchId: "4", name: "6"},
  {id: "30", branchId: "4", name: "7"},
  {id: "31", branchId: "4", name: "8"},

  {id: "32", branchId: "5", name: "1"},
  {id: "33", branchId: "5", name: "2"},
  {id: "34", branchId: "5", name: "3"},
  {id: "35", branchId: "5", name: "4"},
  {id: "36", branchId: "5", name: "5"},
  {id: "37", branchId: "5", name: "6"},
  {id: "38", branchId: "5", name: "7"},
  {id: "39",branchId: "5", name: "8"},

  {id: "40", branchId: "6", name: "1"},
  {id: "41", branchId: "6", name: "2"},
  {id: "42", branchId: "6", name: "3"},
  {id: "43", branchId: "6", name: "4"},
  {id: "44", branchId: "6", name: "5"},
  {id: "45", branchId: "6", name: "6"},
  {id: "46", branchId: "6", name: "7"},
  {id: "47", branchId: "6", name: "8"},

  {id: "48", branchId: "7", name: "1"},
  {id: "49", branchId: "7", name: "2"},
  {id: "50", branchId: "7", name: "3"},
  {id: "51", branchId: "7", name: "4"},
  {id: "52", branchId: "7", name: "5"},
  {id: "53", branchId: "7", name: "6"},
  {id: "54", branchId: "7", name: "7"},
  {id: "55", branchId: "7", name: "8"},

  {id: "56", branchId: "8", name: "1"},
  {id: "57", branchId: "8", name: "2"},
  {id: "58", branchId: "8", name: "3"},
  {id: "59", branchId: "8", name: "4"},
  {id: "60", branchId: "8", name: "5"},
  {id: "61", branchId: "8", name: "6"},
  {id: "62", branchId: "8", name: "7"},
  {id: "63", branchId: "8", name: "8"},

  {id: "64", branchId: "9", name: "1"},
  {id: "65", branchId: "9", name: "2"},
  {id: "66", branchId: "9", name: "3"},
  {id: "67", branchId: "9", name: "4"},
  {id: "68", branchId: "9", name: "5"},
  {id: "69", branchId: "9", name: "6"},
  {id: "70", branchId: "9", name: "7"},
  {id: "71", branchId: "9", name: "8"},

  {id: "72", branchId: "10", name: "1"},
  {id: "73", branchId: "10", name: "2"},
  {id: "74", branchId: "10", name: "3"},
  {id: "75", branchId: "10", name: "4"},
  {id: "76", branchId: "10", name: "5"},
  {id: "77", branchId: "10", name: "6"},
  {id: "78", branchId: "10", name: "7"},
  {id: "79", branchId: "10", name: "8"},

  {id: "80", branchId: "11", name: "1"},
  {id: "81", branchId: "11", name: "2"},
  {id: "82", branchId: "11", name: "3"},
  {id: "83", branchId: "11", name: "4"},
  {id: "84", branchId: "11", name: "5"},
  {id: "85", branchId: "11", name: "6"},
  {id: "86", branchId: "11", name: "7"},
  {id: "87", branchId: "11", name: "8"},

  {id: "88", branchId: "12", name: "1"},
  {id: "89", branchId: "12", name: "2"},
  {id: "90", branchId: "12", name: "3"},
  {id: "91", branchId: "12", name: "4"},
  {id: "92", branchId: "12", name: "5"},
  {id: "93", branchId: "12", name: "6"},
  {id: "94", branchId: "12", name: "7"},
  {id: "95", branchId: "12", name: "8"},


]


const [resStates, setResStates] = useState(Istates);
const [resInstituteTypes, setResInstituteTypes] = useState(IinstituteTypes);
const [resInstitutes, setResInstitutes] = useState(Iinstitutes);
const [resFields, setResFields] = useState(Ifields);
const [resCollage, setResCollage] = useState(Icollages);
const [resBranches, setResBranches] = useState(Ibranches);
const [ressemester, setResSemester] = useState(Isemesters);
const [states, setStates] = useState(Istates);
const [instituteTypes, setInstituteTypes] = useState(IinstituteTypes);
const [institutes, setInstitutes] = useState(Iinstitutes);
const [fields, setFields] = useState(Ifields);
const [collage, setCollage] = useState(Icollages);
const [branches, setBranches] = useState(Ibranches);
const [semester, setSemester] = useState(Isemesters);
const [selectedStateId, setSelectedStateId] = useState("");
const [selectedInstituteTypeId, setSelectedInstituteTypeId] = useState("");
const [selectedInstituteId, setSelectedInstituteId] = useState("");
const [selectedFieldId, setSelectedFieldId] = useState("");
const [selectedCollageId, setSelectedCollageId] = useState("");
const [selectedBranchId, setSelectedBranchId] = useState("");
const [selectedSemsterId, setSelectedSemesterId] = useState("");

// useEffect(() => {
//     // Effect1
//     // !!selectedStateId && setInstituteTypes(resInstituteTypes.filter(item => item.stateId === selectedStateId))
//     // !!selectedInstituteTypeId && setInstitutes(resInstitutes.filter(item => item.institutetypeId === selectedInstituteTypeId))
//     // !!selectedInstituteId && setFields(resFields.filter(item => item.instituteId === selectedInstituteId))
//     // !!selectedFieldId && setBranches(resBranches.filter(item => item.fieldId === selectedFieldId))

//     // Effect2
//     setInstituteTypes(resInstituteTypes.filter(item => item.stateId === selectedStateId))
//     setInstitutes(resInstitutes.filter(item => item.institutetypeId === selectedInstituteTypeId))
//     setFields(resFields.filter(item => item.instituteId === selectedInstituteId))
//     setBranches(resBranches.filter(item => item.fieldId === selectedFieldId))

// }, [selectedStateId, selectedInstituteTypeId, selectedInstituteId, selectedFieldId, selectedBranchId])

  const handleFile = (e) => {
    let file = e.target.files;

    setState({ file: file });
  };

  const handleUpload = (e) => {
    console.log(state, "This state ------$$%%^^&&");
    let file = state.file;
    let formdata = new FormData();

    //
    const nameOfStateId = resStates.filter(
      (item) => item.id === selectedStateId
    );
    const nameOfInstituteTypeId = resInstituteTypes.filter(
      (item) => item.id === selectedInstituteTypeId
    );
    const nameOfInstituteId = resInstitutes.filter(
      (item) => item.id === selectedInstituteId
    );
    const nameOfFieldId = resFields.filter(
      (item) => item.id === selectedFieldId
    );
    const nameOfCollageId = resCollage.filter(
      (item) => item.id === selectedCollageId
    );
    const nameOfBranchId = resBranches.filter(
      (item) => item.id === selectedBranchId
    );

    const nameOfSemesterId = ressemester.filter(
      (item) => item.id === selectedSemsterId
    )

    // CORRECT

    formdata.append("nameOfState", nameOfStateId?.[0]?.name);
    formdata.append("nameOfInstituteType", nameOfInstituteTypeId?.[0]?.name);
    formdata.append("nameOfInstitute", nameOfInstituteId?.[0]?.name);
    formdata.append("nameOfField", nameOfFieldId?.[0]?.name);
    formdata.append("nameOfCollage", nameOfCollageId?.[0].name);
    formdata.append("nameOfBranch", nameOfBranchId?.[0]?.name);
    formdata.append("nameOfSemesterId", nameOfSemesterId?.[0]?.name);

    formdata.append("testKey", "testValue");
    formdata.append("file", file[0]);
    formdata.append("filename", "Bhakti Bhanvadiya");
    // WRONG
    // formdata.append('pdf', file)
    // formdata.append('name', "Bhakti Bhanvadiya")

    fetch("http://127.0.0.1:8080/uploader", {
      method: "POST",
      body: formdata,
    }).then((response) => {
      alert("file upload dev!");
    });
  };

  useEffect(() => {
    // Effect1
    // !!selectedStateId && setInstituteTypes(resInstituteTypes.filter(item => item.stateId === selectedStateId))
    // !!selectedInstituteTypeId && setInstitutes(resInstitutes.filter(item => item.institutetypeId === selectedInstituteTypeId))
    // !!selectedInstituteId && setFields(resFields.filter(item => item.instituteId === selectedInstituteId))
    // !!selectedFieldId && setBranches(resBranches.filter(item => item.fieldId === selectedFieldId))

    // Effect2
    setInstituteTypes(resInstituteTypes.filter((item) => item.stateId === selectedStateId));

    setInstitutes(resInstitutes.filter((item) => item.institutetypeId === selectedInstituteTypeId));

    setFields(resFields.filter((item) => item.instituteId === selectedInstituteId));

    setCollage(resCollage.filter((item) => item.instituteId === selectedInstituteId));

    setBranches(resBranches.filter((item) => item.fieldId === selectedFieldId));

    setSemester(ressemester.filter((item) => item.branchId === selectedBranchId));
  }, [
    selectedStateId,
    selectedInstituteTypeId,
    selectedInstituteId,
    selectedFieldId,
    selectedCollageId,
    selectedBranchId,
    selectedSemsterId
  ]);
  
  //

  return (
    <div id="main">
      <div>
        <div className="logo">
          <img src="./AICTE_LOGO.png" alt="logo" />
        </div>
        <div>
          <hr className="h"></hr>
        </div>
        <div className="App">
          <h1>AICTE Course Mapping Dashboard</h1>
          <div className="box">
            <h3>College Details</h3>
            <div className="display">
              <div className="mainstate">
                <label for="State" className="State">
                  State
                </label>
                <select
                  id="ddlState"
                  className="form-control"
                  onChange={(e) => setSelectedStateId(e.target.value)}
                >
                  <option value="" selected>
                    Select State
                  </option>
                  {states?.length &&
                    states.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>

              <div className="mainstate">
                <label for="State" className="State">
                  Institute Type
                </label>
                <select
                  id="ddlinstitutetype"
                  className="form-control"
                  onChange={(e) => setSelectedInstituteTypeId(e.target.value)}
                >
                  <option value="" selected>
                    Select Institute Type
                  </option>
                  {instituteTypes?.length &&
                    instituteTypes.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>
              <br></br>

              <div className="mainstate">
                <label for="State" className="State">
                  Collage/Institute
                </label>
                <select
                  id="ddlinstitute"
                  className="form-control"
                  onChange={(e) => setSelectedInstituteId(e.target.value)}
                >
                  <option value="0">Select College/Institute</option>
                  {institutes?.length &&
                    institutes.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>
              <br></br>
            </div>

            <div className="display">
              <div className="mainstate">
                <label for="State" className="State">
                  Select Field
                </label>
                <select
                  id="ddlfield"
                  className="form-control"
                  onChange={(e) => setSelectedFieldId(e.target.value)}
                >
                  <option value="0">Select Field</option>
                  {fields?.length &&
                    fields.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>
              <br></br>


              <div className="display">
              <div className="mainstate">
                <label for="State" className="State">
                  Select Collage
                </label>
                <select
                  id="ddlcollage"
                  className="form-control"
                  onChange={(e) => setSelectedCollageId(e.target.value)}
                >
                  <option value="0">Select Collage</option>
                  {collage?.length &&
                    collage.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>
              <br></br>

              <div className="mainstate">
                <label for="State" className="State">
                  Select Branch
                </label>
                <select
                  id="ddlBranch"
                  className="form-control"
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                >
                  <option value="0">Select Branch</option>
                  {branches?.length &&
                    branches.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>

              <br></br>
              

              <div className="mainstate">
                <label for="State" className="State">
                  Select Semester
                </label>
                <select
                  id="ddlSemester"
                  className="form-control"
                  onChange={(e) => setSelectedSemesterId(e.target.value)}
                >
                  <option value="0">Select Semester</option>
                  {semester?.length &&
                    semester.map((item, index) => (
                      <option key={item?.id} value={item?.id}>
                        {item?.name}
                      </option>
                    ))}
                </select>
              </div>
              
            </div>
          </div>
        </div>
      </div>
      <div className="center">
        <div className="file-card">
          <h4>Upload File</h4>
          <div className="file-inputs">
            <input
              type="file"
              multiple
              name="file"
              onChange={(e) => handleFile(e)}
            />
          </div>
          <br />
          <button type="button" onClick={(e) => handleUpload(e)}>
            Upload
          </button>
        </div>
      </div>
    </div>
  </div>
    
  );
}


export default Header;
